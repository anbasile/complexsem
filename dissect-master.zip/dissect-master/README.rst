DIStributional SEmantics Composition Toolkit
============================================


For documentation, please, refer to http://clic.cimec.unitn.it/composes/toolkit/
