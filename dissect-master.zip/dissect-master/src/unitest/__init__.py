current_file = __file__
toolkit_dir = "/".join(current_file.split("/")[0:-3])
data_dir = toolkit_dir + "/resource/unittest/"